package com.example.rpgdiceapp

import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.rpgdiceapp.api.ApiService

class ProfileActivity : AppCompatActivity() {
    private lateinit var profileImageView: ImageView
    private lateinit var usernameTextView: TextView
    private lateinit var fullNameTextView: TextView
    private lateinit var emailTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        profileImageView = findViewById(R.id.profileImageView)
        usernameTextView = findViewById(R.id.usernameTextView)
        fullNameTextView = findViewById(R.id.fullNameTextView)
        emailTextView = findViewById(R.id.emailTextView)

        val intent = intent
        val username = intent.getStringExtra("username")
        val firstName = intent.getStringExtra("firstName")
        val surname = intent.getStringExtra("surname")
        val email = intent.getStringExtra("email")
        val userPhotoPath = intent.getStringExtra("userPhotoPath")

        if (username != null && firstName != null && surname != null && email != null && userPhotoPath != null) {
            // ✅ Dane przekazane z LoginActivity
            setProfileData(username, firstName, surname, email, userPhotoPath)
        } else {
            // ❌ Brak danych – fallback: zapytanie do API
            Log.w("PROFILE", "Brak danych w Intent – wykonuję GET /api/v1/authorized/user")

            val apiService = ApiService()
            apiService.getAuthorizedUser(
                onSuccess = { user ->
                    runOnUiThread {
                        setProfileData(
                            user.username,
                            user.firstName,
                            user.surname,
                            user.email,
                            user.userPhotoPath
                        )
                    }
                },
                onError = { err ->
                    Log.e("PROFILE", "Błąd pobierania danych użytkownika: $err")
                    runOnUiThread {
                        emailTextView.text = "Błąd ładowania danych: $err"
                    }
                }
            )
        }
    }

    private fun setProfileData(
        username: String,
        firstName: String,
        surname: String,
        email: String,
        userPhotoPath: String?
    ) {
        usernameTextView.text = username
        fullNameTextView.text = "$firstName $surname"
        emailTextView.text = email

        val fallbackPath = "/img/profilePics/defaultProfilePic.png"
        val photoUrl = "http://10.0.2.2:8888${userPhotoPath ?: fallbackPath}"

        Glide.with(this)
            .load(photoUrl)
            .placeholder(R.drawable.ic_default_profile)
            .error(R.drawable.ic_default_profile)
            .circleCrop()
            .into(profileImageView)
    }
}
