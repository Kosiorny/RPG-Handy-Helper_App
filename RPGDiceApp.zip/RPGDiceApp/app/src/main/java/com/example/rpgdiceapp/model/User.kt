package com.example.rpgdiceapp.model

data class User(
    val login: String,
    val password: String
)