package com.example.rpgdiceapp.model

data class RegisterResponse(
    val error: Int,
    val message: String
)
