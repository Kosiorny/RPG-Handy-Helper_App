package com.example.rpgdiceapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.rpgdiceapp.api.ApiService
import com.google.android.gms.safetynet.SafetyNet
import com.google.android.gms.safetynet.SafetyNetApi
import com.google.android.gms.tasks.OnSuccessListener
import com.google.android.gms.tasks.OnFailureListener

class RegisterActivity : AppCompatActivity() {

    private val siteKey = "6Lfz_BsqAAAAAPepoWRQn1x7rQAxALA-wyfsjrzM"  // Zmień na własny jeśli masz

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val username = findViewById<EditText>(R.id.registerUsername)
        val firstName = findViewById<EditText>(R.id.registerFirstName)
        val surname = findViewById<EditText>(R.id.registerSurname)
        val email = findViewById<EditText>(R.id.registerEmail)
        val password = findViewById<EditText>(R.id.registerPassword)
        val confirmPassword = findViewById<EditText>(R.id.registerConfirmPassword)
        val registerBtn = findViewById<Button>(R.id.registerButton)

        registerBtn.setOnClickListener {
            val user = username.text.toString()
            val pass = password.text.toString()
            val confirm = confirmPassword.text.toString()
            val fname = firstName.text.toString()
            val lname = surname.text.toString()
            val mail = email.text.toString()

            if (pass != confirm) {
                Toast.makeText(this, "Hasła się nie zgadzają", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 🔐 Uzyskaj token reCAPTCHA
            SafetyNet.getClient(this).verifyWithRecaptcha(siteKey)
                .addOnSuccessListener(this, OnSuccessListener<SafetyNetApi.RecaptchaTokenResponse> { response ->
                    val token = response.tokenResult
                    if (!token.isNullOrEmpty()) {
                        // TODO: pobierz CSRF z ciasteczka lub endpointa
                        val csrfToken = "" // <- musisz go zdobyć (omówimy zaraz)

                        val apiService = ApiService()
                        apiService.registerWithCaptcha(
                            username = user,
                            password = pass,
                            firstName = fname,
                            surname = lname,
                            email = mail,
                            captchaToken = token,
                            csrfToken = csrfToken,
                            onSuccess = {
                                runOnUiThread {
                                    Toast.makeText(this, "Zarejestrowano! Sprawdź e-mail.", Toast.LENGTH_LONG).show()
                                    finish()
                                }
                            },
                            onError = { err ->
                                runOnUiThread {
                                    Toast.makeText(this, "Błąd: $err", Toast.LENGTH_LONG).show()
                                }
                            }
                        )
                    }
                })
                .addOnFailureListener(this, OnFailureListener { e ->
                    Toast.makeText(this, "Błąd reCAPTCHA: ${e.message}", Toast.LENGTH_SHORT).show()
                })
        }
    }
}
