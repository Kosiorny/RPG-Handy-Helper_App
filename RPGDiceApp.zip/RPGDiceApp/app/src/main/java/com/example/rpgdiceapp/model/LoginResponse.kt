package com.example.rpgdiceapp.model

data class LoginResponse(
    val username: String,
    val firstName: String,
    val surname: String,
    val email: String,
    val userPhotoPath: String
)
