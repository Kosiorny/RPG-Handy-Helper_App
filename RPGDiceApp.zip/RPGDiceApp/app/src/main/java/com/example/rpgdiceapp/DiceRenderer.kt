package com.example.rpgdiceapp

import android.content.Context
import android.util.Log
import org.rajawali3d.Object3D
import org.rajawali3d.loader.LoaderOBJ
import org.rajawali3d.loader.ParsingException
import org.rajawali3d.math.vector.Vector3
import org.rajawali3d.renderer.Renderer
import kotlin.random.Random

class DiceRenderer(context: Context) : Renderer(context) {

    private var dice: Object3D? = null

    override fun initScene() {
        currentScene.camera.position = Vector3(0.0, 0.0, 6.0)
        currentScene.camera.lookAt(0.0, 0.0, 0.0)

        try {
            val loader = LoaderOBJ(context.resources, textureManager, "d6.obj")
            loader.parse()
            dice = loader.parsedObject
            dice?.apply {
                scale = 1.5
                position = Vector3(0.0, 0.0, 0.0)
            }
            currentScene.addChild(dice)
        } catch (e: ParsingException) {
            Log.e("DiceRenderer", "Model load failed: ${e.message}")
        }
    }

    fun rollDice() {
        val x = Random.nextDouble(0.0, 360.0)
        val y = Random.nextDouble(0.0, 360.0)
        val z = Random.nextDouble(0.0, 360.0)

        dice?.setRotation(Vector3(x, y, z))
    }

    override fun onOffsetsChanged(
        xOffset: Float, yOffset: Float,
        xOffsetStep: Float, yOffsetStep: Float,
        xPixelOffset: Int, yPixelOffset: Int
    ) {
        // wymagane przez abstrakcyjną klasę Renderer
    }
}
