package com.example.rpgdiceapp

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import dev.romainguy.kotlin.math.Float3
import io.github.sceneview.SceneView
import io.github.sceneview.loaders.ModelLoader
import io.github.sceneview.node.ModelNode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sqrt
import kotlin.random.Random

class DiceComposeActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accel = 0f
    private var accelCurrent = 0f
    private var accelLast = 0f
    private var canRoll = true
    private var modelNode: ModelNode? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManager.registerListener(
            this,
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
            SensorManager.SENSOR_DELAY_UI
        )

        accel = 10f
        accelCurrent = SensorManager.GRAVITY_EARTH
        accelLast = SensorManager.GRAVITY_EARTH

        setContent {
            DiceScene(modifier = Modifier.fillMaxSize(), onModelNodeReady = { modelNode = it })
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val x = event?.values?.get(0) ?: 0f
        val y = event?.values?.get(1) ?: 0f
        val z = event?.values?.get(2) ?: 0f
        accelLast = accelCurrent
        accelCurrent = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
        val delta = accelCurrent - accelLast
        accel = accel * 0.9f + delta

        if (accel > 12 && canRoll) {
            canRoll = false
            rollDice()
            window.decorView.postDelayed({ canRoll = true }, 1500)
        }
    }

    private fun rollDice() {
        modelNode?.let { node ->
            val rx = Random.nextFloat() * 360
            val ry = Random.nextFloat() * 360
            val rz = Random.nextFloat() * 360
            node.transform.rotation.setAll(rx, ry, rz)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onResume() {
        super.onResume()
        sensorManager.registerListener(
            this,
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
            SensorManager.SENSOR_DELAY_UI
        )
    }
}

@Composable
fun DiceScene(modifier: Modifier = Modifier, onModelNodeReady: (ModelNode) -> Unit) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            SceneView(context).apply {
                val loader = ModelLoader(engine, context)
                CoroutineScope(Dispatchers.Main).launch {
                    val model = loader.createModel("models/d6.glb") ?: return@launch
                    val node = ModelNode(model.instance).apply {
                        transform.apply {
                            position.set(0f, 0f, -1f)
                            scale.set(0.2f)
                        }
                    }
                    scene.children += node
                    onModelNodeReady(node)
                }
            }
        }
    )
}
