package com.example.rpgdiceapp.util

import com.google.android.gms.safetynet.SafetyNet
import com.google.android.gms.safetynet.SafetyNetApi
import com.google.android.gms.tasks.OnSuccessListener
import com.google.android.gms.tasks.OnFailureListener
import android.content.Context

object CaptchaHelper {
    private const val SITE_KEY = "6LeBDk4rAAAAABtiIPwh4RKlmKCS0dHxoWIJYSMN"

    fun getCaptchaToken(context: Context, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        SafetyNet.getClient(context).verifyWithRecaptcha(SITE_KEY)
            .addOnSuccessListener { response ->
                val token = response.tokenResult
                if (!token.isNullOrEmpty()) {
                    onSuccess(token)
                } else {
                    onError("Token jest pusty")
                }
            }
            .addOnFailureListener { error ->
                onError("Błąd reCAPTCHA: ${error.message}")
            }
    }
}

