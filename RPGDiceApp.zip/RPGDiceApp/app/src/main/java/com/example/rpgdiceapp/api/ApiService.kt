package com.example.rpgdiceapp.api

import android.util.Log
import com.example.rpgdiceapp.model.LoginResponse
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.net.CookieManager
import java.net.CookiePolicy
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Request
import java.io.IOException


class ApiService {
    private val baseUrl = "http://10.0.2.2:8888"

    private val cookieManager = CookieManager().apply {
        setCookiePolicy(CookiePolicy.ACCEPT_ALL)
    }

    private val client = OkHttpClient.Builder()
        .cookieJar(JavaNetCookieJar(cookieManager))
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val api = retrofit.create(ApiInterface::class.java)

    fun login(username: String, password: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        api.login(username, password).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    onSuccess()
                } else {
                    onError("Błąd logowania: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                onError("Błąd sieci: ${t.message}")
            }
        })
    }

    fun registerWithCaptcha(
        username: String,
        password: String,
        firstName: String,
        surname: String,
        email: String,
        captchaToken: String,
        csrfToken: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val json = """
        {
            "username": "$username",
            "password": "$password",
            "firstName": "$firstName",
            "surname": "$surname",
            "email": "$email",
            "captcha": "$captchaToken",
            "_csrf": "$csrfToken"
        }
    """.trimIndent()

        val mediaType = "application/json".toMediaTypeOrNull()
        val requestBody = json.toRequestBody(mediaType)

        val request = Request.Builder()
            .url("$baseUrl/api/v1/register/signup")
            .post(requestBody)
            .addHeader("Content-Type", "application/json")
            .addHeader("X-XSRF-TOKEN", csrfToken)
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                Log.e("ApiService", "Register failed: ${e.message}")
                onError("Błąd sieci: ${e.message}")
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.use {
                    if (it.isSuccessful) {
                        Log.i("ApiService", "Register successful")
                        onSuccess()
                    } else {
                        val errorBody = it.body?.string()
                        Log.e("ApiService", "Register error: ${it.code} - $errorBody")
                        onError("Błąd rejestracji: ${it.code}")
                    }
                }
            }
        })
    }




    fun getAuthorizedUser(onSuccess: (LoginResponse) -> Unit, onError: (String) -> Unit) {
        api.getAuthorizedUser().enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        onSuccess(it)
                    } ?: onError("Brak danych użytkownika")
                } else {
                    onError("Błąd pobierania użytkownika: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                onError("Błąd sieci: ${t.message}")
            }
        })
    }
}
