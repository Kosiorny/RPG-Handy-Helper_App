package com.example.rpgdiceapp.api

import com.example.rpgdiceapp.model.LoginResponse
import com.example.rpgdiceapp.model.RegisterRequest
import com.example.rpgdiceapp.model.RegisterResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiInterface {
    @FormUrlEncoded
    @POST("/login")
    fun login(
        @Field("username") username: String,
        @Field("password") password: String
    ): Call<Void> // jeśli backend nic nie zwraca – jeśli zwraca token, daj LoginResponse

    @FormUrlEncoded
    @POST("/api/v1/register/signup")
    fun register(@Body request: RegisterRequest): Call<RegisterResponse>




    @GET("/api/v1/authorized/user")
    fun getAuthorizedUser(): Call<LoginResponse>
}
