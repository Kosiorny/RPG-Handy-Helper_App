package com.example.rpgdiceapp

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.ar.sceneform.Node
import com.google.ar.sceneform.math.Vector3
import com.google.ar.sceneform.rendering.ModelRenderable
import io.github.sceneview.SceneView

class DiceActivity : AppCompatActivity() {

    private lateinit var sceneView: SceneView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dice)

        sceneView = findViewById(R.id.sceneView)

        ModelRenderable.builder()
            .setSource(this, Uri.parse("file:///android_asset/d6.glb"))
            .setIsFilamentGltf(true)
            .build()
            .thenAccept { modelRenderable ->
                val node = Node().apply {
                    renderable = modelRenderable
                    localPosition = Vector3(0f, 0f, -1f)
                }
                sceneView.scene.addChild(node)
            }
            .exceptionally {
                it.printStackTrace()
                null
            }
    }
}
