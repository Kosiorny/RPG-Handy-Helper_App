package com.example.rpgdiceapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.rpgdiceapp.api.ApiService

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val loginField = findViewById<EditText>(R.id.loginEditText)
        val passwordField = findViewById<EditText>(R.id.passwordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)

        loginButton.setOnClickListener {
            val login = loginField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            if (login.isBlank() || password.isBlank()) {
                Toast.makeText(this, "Uzupełnij login i hasło", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val apiService = ApiService()

            apiService.login(login, password,
                onSuccess = {
                    Log.d("LOGIN", "Logowanie udane, pobieram dane użytkownika...")

                    apiService.getAuthorizedUser(
                        onSuccess = { userData ->
                            Log.d("USER_DATA", "Pobrano dane: $userData")

                            runOnUiThread {
                                val intent = Intent(this, ProfileActivity::class.java).apply {
                                    putExtra("username", userData.username)
                                    putExtra("firstName", userData.firstName)
                                    putExtra("surname", userData.surname)
                                    putExtra("email", userData.email)
                                    putExtra("userPhotoPath", userData.userPhotoPath)
                                }
                                startActivity(intent)
                                finish()
                            }
                        },
                        onError = { err ->
                            Log.e("USER_FETCH_ERROR", err)
                            runOnUiThread {
                                Toast.makeText(this, "Błąd pobierania użytkownika: $err", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                },
                onError = { err ->
                    Log.e("LOGIN_ERROR", err)
                    runOnUiThread {
                        Toast.makeText(this, "Błąd logowania: $err", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }
}
