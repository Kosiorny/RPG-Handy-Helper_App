package com.example.rpgdiceapp.model

data class RegisterRequest(
    val username: String,
    val password: String,
    val passwordConfirm: String,
    val firstName: String,
    val surname: String,
    val email: String,
    val captcha: String,
    val _csrf: String
)
